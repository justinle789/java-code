/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java.more.advanced.skills.pkg1;
import java.util.Scanner;
//import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.*;

/**
 *
 * @author S328169883
 */
public class JavaMoreAdvancedSkills1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //ArrayList<Integer> arra = new ArrayList<>();
        Scanner input = new Scanner(System.in);
        int beg; 
        int mid; 
        int end;  
        //int arra[] = {1,2,5,25,15,14,19,22,30,28,8,11,7};
        Random ran = new Random();
        Arrays arra[] = new Arrays [30];
        //arra[] a = new arra[];
        
        System.out.println("What number do you pick between 0 to 30.");
        int theirInput = input.nextInt();
        System.out.println("I will show you how binary search works.");
        for (int i=0; i<30; i++){
          arra.add(ran.nextInt(30));
          //arra[i]= n;
        }
        System.out.println("This is the array unsorted" + Arrays.toString(arra));
        Arrays.sort(arra);
        System.out.println("This is the array sorted" + Arrays.toString(arra));
        int returnValue = Arrays.binarySearch(arra,theirInput);
        System.out.println(returnValue);
    }
    
  }
    

